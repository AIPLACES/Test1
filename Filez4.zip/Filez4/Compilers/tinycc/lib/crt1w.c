#define _UNICODE 1
#define UNICODE 1
#include "crt1.c"
